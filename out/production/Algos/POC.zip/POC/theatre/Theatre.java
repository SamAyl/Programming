package POC.theatre;


public abstract class Theatre {

    String theatreType;
    Integer numberOfScreens;


}
